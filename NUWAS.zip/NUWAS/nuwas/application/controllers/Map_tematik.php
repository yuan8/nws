<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class map_tematik extends CI_Controller {

  public function index(){

    return view('dashboard.map');
    
  }
}
