<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{

		// $data=query($this,'select
		// 		a.kode_daerah,
		//
		// 		sum(a.anggaran) as jml_anggaran,
		// 		count(DISTINCT(CONCAT(a.kode_daerah,a.kode_program))) as jml_program,
		// 		count(DISTINCT(CONCAT(a.kode_daerah,a.kode_kegiatan))) as jml_kegiatan
		// 		from program_kegiatan_sipd2 a
		// 		group by
		// 		a.kode_daerah
		//
		// 	');

		$data_return=[];






	   return view('pages.index',['title'=>'Dashboard']);
	}

	public function t(){
		return view('index');

	}

	public function keuangan_pu(){
		return view('keuangan_pu',['title'=>'Profile PU']);
	}

}
