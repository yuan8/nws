


<?php $__env->startSection('content'); ?>
<div class="card card-primary">
  <div class="card-body">
      dd
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.lay1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/NUWAS/nuwas/application/views/dashboard/map.blade.php ENDPATH**/ ?>