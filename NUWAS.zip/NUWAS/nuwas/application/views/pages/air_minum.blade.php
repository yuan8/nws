
@extends('template.lay1')

@section('content')
<div class="row no-gutters bg-def">
    <div class="col-md-12">

    </div>
      <div class="col-md-12" id="chart-container">
      </div>
</div>

@stop

@section('script')
<script type="text/javascript">
// Set up the chart
$.get("{{rt('/air_minum/from_urusan')}}",function(res){
  build(res.categories,res.series);
})


function build(){


var chart = new Highcharts.Chart({
    chart: {
        renderTo: 'chart-container',
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 15,
            beta: 15,
            depth: 50,
            viewDistance: 25
        },
        backgroundColor:'transparent',
        borderColor:'transparent'
    },
    title: {
        text: 'Chart rotation demo',
        style:{
          color:'#fff'
        }
    },
    subtitle: {
        text: 'Test options by dragging the sliders below',
        style:{
          color:'#fff'
        }
    },
    colors:['#fff','yellow'],
    plotOptions: {
        column: {
            depth: 25
        }
    },
    series: [{
        data: [129.9, 171.5, 106.4, 100.2, 100.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
    }]
});
}

// function showValues() {
//     $('#alpha-value').html(chart.options.chart.options3d.alpha);
//     $('#beta-value').html(chart.options.chart.options3d.beta);
//     $('#depth-value').html(chart.options.chart.options3d.depth);
// }
//
// // Activate the sliders
// $('#sliders input').on('input change', function () {
//     chart.options.chart.options3d[this.id] = parseFloat(this.value);
//     showValues();
//     chart.redraw(false);
// });
//
// showValues();

</script>
@stop
