
@extends('template.lay1')

@section('content')
<div class="card card-primary">
  <div class="card-body">
      dd
  </div>
</div>
@stop
